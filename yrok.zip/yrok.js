

      const hendshake=120; 

      function getPeople(hendshake){
        let ludi=1;
        let chet=0; 
        for (ludi=1; chet<=hendshake;ludi++){ 
            hendshake=hendshake-ludi;
            if(hendshake===0){
                break
            }
        }      
        console.log(ludi)
      }
      getPeople(hendshake)